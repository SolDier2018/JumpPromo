create definer = root@localhost trigger `Insert GrayList Point`
    before INSERT
    on f_graylist_coords
    for each row
    SET NEW.coords = POINT(NEW.longitude, NEW.latitude);

