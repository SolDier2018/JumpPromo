create definer = root@localhost trigger `Update City Point`
    before UPDATE
    on city
    for each row
    SET NEW.coords = POINT(NEW.longitude, NEW.latitude);

