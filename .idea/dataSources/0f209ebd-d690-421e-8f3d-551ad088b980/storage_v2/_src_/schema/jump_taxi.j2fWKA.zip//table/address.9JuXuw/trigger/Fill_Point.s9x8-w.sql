create definer = root@localhost trigger `Fill Point`
    before INSERT
    on address
    for each row
    SET NEW.coords = POINT(NEW.longitude, NEW.latitude);

