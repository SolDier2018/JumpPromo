create definer = root@localhost trigger `Update GrayList Point`
    before UPDATE
    on f_graylist_coords
    for each row
    SET NEW.coords = POINT(NEW.longitude, NEW.latitude);

