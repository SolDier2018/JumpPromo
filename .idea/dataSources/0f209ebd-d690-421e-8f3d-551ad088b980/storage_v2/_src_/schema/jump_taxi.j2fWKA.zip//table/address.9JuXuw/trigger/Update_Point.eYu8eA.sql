create definer = root@localhost trigger `Update Point`
    before UPDATE
    on address
    for each row
    SET NEW.coords = POINT(NEW.longitude, NEW.latitude);

