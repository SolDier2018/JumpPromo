create definer = root@localhost trigger `Fill City Point`
    before INSERT
    on city
    for each row
    SET NEW.coords = POINT(NEW.longitude, NEW.latitude);

