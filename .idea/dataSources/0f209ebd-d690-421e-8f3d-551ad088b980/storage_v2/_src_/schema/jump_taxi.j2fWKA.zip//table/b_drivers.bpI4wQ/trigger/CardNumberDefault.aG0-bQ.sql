create definer = root@localhost trigger CardNumberDefault
    before INSERT
    on b_drivers
    for each row
    IF (NEW.cardNumber IS NULL) THEN
    SET NEW.cardNumber = CONCAT('Б', (SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='b_drivers'));
END IF;

